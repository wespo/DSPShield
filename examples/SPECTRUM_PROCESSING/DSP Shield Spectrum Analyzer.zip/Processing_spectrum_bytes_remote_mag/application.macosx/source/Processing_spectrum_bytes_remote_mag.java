import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.serial.*; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Processing_spectrum_bytes_remote_mag extends PApplet {

/*
  Sketch to print the spectrum recieved from the C5535 DSP Shield
 */
int baudRate = 921600;//921600;
int maxRows = 4;
float recvSpectrum[] = new float[4096]  ; //array of values recieved from the DSP Shield
float avgSpectrumL[][] = new float[256][4096];
float avgSpectrumR[][] = new float[256][4096];

int rowMarkerL = 0;
int rowMarkerR = 0;
int spectrumMode = 1; //0 == processing expects complex spectrum; 1== processing expects real spectrum 
int[] spectrumPosition = {
  400 - 512/2, 10
}; //position of DSP Shield spectrum window.
int[] spectrumSize = {
  512, 512
}; //dimensions of DSP Shield spectrum window. 
int newFrame = 0; //global status to indicate that a new frame has been recieved.

 //serial library.
Serial myPort;        // The serial port

 //GUI library
ControlP5 cp5;

public float log10 (float x) { //returns the base10 logarithm of a float as a float
  return (log(x) / log(10));
}
public void drawSpectrumWindow() {
  //draws spectrum window according to globals. Sets up colors to draw spectrum itself.
  fill(0);
  stroke(255, 255, 255);
  rect(spectrumPosition[0], spectrumPosition[1], spectrumSize[0], spectrumSize[1]);
}

public void drawSpectrum(float[] spectrum, int[] position, int specColor) //draws the actual spectrum.
//data: the spectrum to draw
//position: a tuple {x,y} of the top left corner of the spectrum
{
  if (spectrum.length == 0)
    return;
  if (specColor == 0)
    stroke(0, 255, 0);
  else
    stroke(255, 0, 0);
  int lineSpacing = spectrumSize[0]/spectrum.length;
  for (int i = 0; i < spectrum.length; i++)
  {
    line(1+i*lineSpacing+position[0], position[1]+spectrumSize[1]-2, 1+i*lineSpacing+position[0], position[1]+spectrumSize[1] - spectrum[i]);
  }
}

public void drawFrequencyIndex(int fStep, int fSamp, int[] windowPosition, int[] windowSize) //draws the scale at the bottom of the grid.
{
  pushMatrix();
  float markerSize = 8;
  PFont f = createFont("Futura", markerSize, true);
  int fCount = 0;
  fill(255);
  textFont(f);
  translate(spectrumPosition[0], spectrumPosition[1] + spectrumSize[1] + markerSize);
  for (int i = 0; i < fSamp/2; i+=fStep)
  {
    rotate(PI/4);
    text(i, 0, 0);
    rotate(-PI/4);    
    translate(fStep*windowSize[0]*2/fSamp, 0);
  }
  popMatrix();
}
public void drawDbIndex(int fStep, int fSamp, int[] windowPosition, int[] windowSize) //draws the scale at the bottom of the grid.
{
  pushMatrix();
  float markerSize = 8;
  PFont f = createFont("Futura", markerSize, true);
  int fCount = 0;
  fill(255);
  textFont(f);
  translate(spectrumPosition[0], spectrumPosition[1] + spectrumSize[1] + markerSize);
  for (int i = 0; i < fSamp/2; i+=fStep)
  {
    rotate(PI/4);
    text(i, 0, 0);
    rotate(-PI/4);    
    translate(fStep*windowSize[0]*2/fSamp, 0);
  }
  popMatrix();
}

public void drawGridVertical(int fStep, int fSamp, int[] windowPosition, int[] windowSize) //draws vertical grid lines
{
  pushMatrix();
  stroke(255, 50.0f);
  translate(windowPosition[0], windowPosition[1] + windowSize[1]);
  for (int i = 0; i < fSamp/2; i+=fStep)
  {
    line(0, 0, 0, -spectrumSize[1]);
    translate(fStep*windowSize[0]*2/fSamp, 0);
  }
  popMatrix();
}

public void drawGridHorizontal(float dBmin, float dBmax, float dBstep, int[] windowPosition, int[] windowSize) //draws vertical grid lines
{
  pushMatrix();
  stroke(255, 50.0f);
  translate(windowPosition[0], windowPosition[1]);
  float pxPerDB = abs(windowSize[0] / (dBmax-dBmin));
  for (float i = dBmin; i < dBmax; i+=dBstep)
  {
    line(0, 0, windowSize[0], 0);
    translate(0, dBstep*pxPerDB);
  }
  popMatrix();
}

public void drawLogo(float x, float y) //draws the logo at X,Y
{
  float heightTitle = 24;
  float heightSubtitle = 13.5f;
  PFont f = createFont("Futura", heightTitle, true);
  String appTitle = "DSP Shield";
  String appSubtitle = "Spectrum Analyzer";

  fill(255);
  textFont(f);
  text(appTitle, x, y+heightTitle);
  textFont(f, heightSubtitle);
  text(appSubtitle, x, y+heightTitle + 5 + heightSubtitle);
}

//add controls here;
DropdownList d1, d2;
public void drawControls() //draw new controlP5 controls.
{
  pushMatrix();
  translate(spectrumPosition[0] + spectrumSize[0]+10, spectrumPosition[1]); //offset all controls

  float heightTitle = 10;
  PFont f = createFont("Futura", heightTitle, true);
  textFont(f);
  fill(255);
  text("Display Controls", 0, heightTitle);


  cp5 = new ControlP5(this);
  // create a new button with name 'buttonA'
  cp5.addButton("ResetSerial")
    .setValue(0)
      .setPosition(8, 90)
        .setSize(100, 19)
          ;


  d1 = cp5.addDropdownList("Serial Port").setPosition(8, 75);

  customize(d1, Serial.list()); // customize the first list
  d1.setIndex(Serial.list().length-1);

  d2 = cp5.addDropdownList("Number Averages").setPosition(8, 144).setCaptionLabel("Number of Averages");
  String[] averages = {
    "1", "2", "4", "8", "16", "32", "64", "128", "256"
  };
  customize(d2, averages); // customize the first list
  d2.setIndex(0);


  popMatrix();
}
public void ResetSerial() {
  resetSerial(PApplet.parseInt(d1.getValue()));
}
public void customize(DropdownList ddl, String[] list) {
  // a convenience function to customize a DropdownList
  ddl.setBackgroundColor(color(190));
  ddl.setItemHeight(20);
  ddl.setBarHeight(15);
  ddl.captionLabel().set("dropdown");
  ddl.captionLabel().style().marginTop = 3;
  ddl.captionLabel().style().marginLeft = 3;
  ddl.valueLabel().style().marginTop = 3;
  for (int i=0; i<list.length; i++) {
    ddl.addItem(list[i], i);
  }
  //ddl.scroll(0);
  ddl.setColorBackground(color(60));
  ddl.setColorActive(color(255, 128));
}

public void controlEvent(ControlEvent theEvent) {
  // DropdownList is of type ControlGroup.
  // A controlEvent will be triggered from inside the ControlGroup class.
  // therefore you need to check the originator of the Event with
  // if (theEvent.isGroup())
  // to avoid an error message thrown by controlP5.

  if (theEvent.isGroup()) {
    // check if the Event was triggered from a ControlGroup
    if (theEvent.group().name() == "Serial Port")
    {
      resetSerial(PApplet.parseInt(theEvent.group().value()));
    }
    if (theEvent.group().name() == "Number Averages")
    {
      println(pow(2, PApplet.parseInt(theEvent.group().value())));
      setAverage(PApplet.parseInt(pow(2, PApplet.parseInt(theEvent.group().value()))));
    }
    println("event from group : "+theEvent.getGroup().getValue()+" from "+theEvent.getGroup());
  } 
  else if (theEvent.isController()) {
    println("event from controller : "+theEvent.getController().getValue()+" from "+theEvent.getController());
  }
}
public float[] averageVector(float[][] avgVector) //takes the average of a multi-row vector.
{
  if (maxRows > 1)
  {
    float avg[] = new float[256];
    for (int i = 0; i < 256; i++)
    {
      avg[i] = 0;
      for (int j = 0; j < maxRows; j++)
      {
        avg[i] += avgVector[j][i];
      }
      avg[i] /= maxRows;
    }
    return avg;
  } 
  else
  {
    return avgVector[0];
  }
}

public void setAverage(int numAvgs) //sets up variables for the number of averages.
{
  maxRows = numAvgs; //set number of rows in the table
  avgSpectrumL = new float[256][256]; //new row table
  avgSpectrumR = new float[256][256]; //new row table
  rowMarkerL = 0;  //set pointer to 0. This is important because if the user is decreasing the number of rows, the pointer will be out of range.
  rowMarkerR = 0;  //set pointer to 0. This is important because if the user is decreasing the number of rows, the pointer will be out of range.
}

public void resetSerial(int port)
{
  myPort.stop();
  myPort = new Serial(this, Serial.list()[port], baudRate);//1843200
}

public void setup () {
  // set the window size:
  size(800, 600);        
  frame.setTitle("DSP Shield Spectrum Analyzer");
  // The last port in the serial list on my mac is always my Arduino
  myPort = new Serial(this, Serial.list()[Serial.list().length-1], baudRate);//1843200
  println(Serial.list()[Serial.list().length-1]);
  // don't generate a serialEvent() unless you get a newline character:
  myPort.bufferUntil('\n');

  // set inital background:
  background(50, 50, 50);
  drawLogo(10, 10);
  drawSpectrumWindow();
  drawControls();
  drawTextLabels();
  drawFrequencyIndex(2000, 44100, spectrumPosition, spectrumSize);
  drawGridVertical(2000, 44100, spectrumPosition, spectrumSize);
  drawGridHorizontal(-100, 0, 20, spectrumPosition, spectrumSize);
}

public void drawTextLabels()
{
  float heightTitle = 24;
  float heightSubtitle = 10;
  PFont f = createFont("Futura", heightTitle, true);
  fill(255);
  textFont(f, heightSubtitle);
  text("Number of Averages", 8, 12);
}

public void draw () {
  background(50, 50, 50);
  drawLogo(10, 10);
  drawSpectrumWindow();
  // everything happens in the serialEvent()
  // draw the line:
  drawTextLabels();
  drawSpectrumWindow();
  drawSpectrum(averageVector(avgSpectrumL), spectrumPosition, 0);
  drawSpectrum(averageVector(avgSpectrumR), spectrumPosition, 1);
  drawFrequencyIndex(2000, 44100, spectrumPosition, spectrumSize);
  drawGridVertical(2000, 44100, spectrumPosition, spectrumSize);
  drawGridHorizontal(-100, 0, 20, spectrumPosition, spectrumSize);
}

public float sign16(float in) //converts unsigned to signed, with a Q.15 precision.
{
  if (in >= 32768)
  {
    in = in - 65536;
  }  
  return in;
}

public void serialEvent (Serial myPort) { //new serial recieve interrupt.
  try {
    int channelFlag = 0;
    // get the ASCII string:
    String inString = myPort.readStringUntil('\n');
    if (inString != null) {
      String values = inString.substring(inString.indexOf("$"));
      if (spectrumMode == 0)
      {
        recvSpectrum = new float[(values.length()-1)/8]; //array of values recieved from the DSP Shield
        for (int i = 1; i+8 < values.length ()-1; i+=8) //every 8 hex characters is a RE+IM pair.
        {
          String inRE = values.substring(i, i+4);
          String inIM = values.substring(i+4, i+8);

          float inByteRE = unhex(inRE);
          inByteRE = sign16(inByteRE);
          float inByteIM = unhex(inIM);
          inByteIM = sign16(inByteIM);
          //print(inByteRE, "+", inByteIM, ", "); 
          float inByte = abs(pow(inByteRE, 2) + pow(inByteIM, 2));
          if (i == 1)
          {
            channelFlag = PApplet.parseInt(inByteIM);
            inByteIM = 0;
          }
          inByte = 20*log10(inByte);
          inByte = map(inByte, 0, 140, 0, spectrumSize[1]);

          recvSpectrum[PApplet.parseInt((i-1)/8)] = inByte;
        }
      }
      else
      {
        recvSpectrum = new float[(values.length()-1)/4]; //array of values recieved from the DSP Shield
        for (int i = 1; i+4 < values.length ()-1; i+=4)
        {
          String in = values.substring(i, i+4);
          float inByte = unhex(in);
          //print(inByte, ",");
          if (i == 5)
          {
            channelFlag = PApplet.parseInt(inByte);
            inByte = 0;
          }
          inByte = sign16(inByte);
          inByte = 40*log10(inByte);
          inByte = map(inByte, 0, 140, 0, spectrumSize[1]);
          recvSpectrum[PApplet.parseInt((i-1)/4)] = inByte;
        }
        //print("\n");
      }
      //println(channelFlag);
      if (channelFlag == 65408)
      {
        avgSpectrumL[rowMarkerL] = recvSpectrum;
        rowMarkerL++;
        if (rowMarkerL > (maxRows - 1))
        {
          rowMarkerL = 0;
        }
      }
      else
      {
        avgSpectrumR[rowMarkerR] = recvSpectrum;
        rowMarkerR++;
        if (rowMarkerR > (maxRows - 1))
        {
          rowMarkerR = 0;
        }
      }
    }
  }
  catch(Exception e) {
    println("Serial Exception");
  }
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Processing_spectrum_bytes_remote_mag" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
